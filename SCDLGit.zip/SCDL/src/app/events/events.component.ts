import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {
  events: Array<{ title: string, date: string, description: string }>;

  constructor() {
    this.events = [
      {
        title: 'Symbiosis Skills and Professional University Initiative for Women Empowerment',
        date: '8 March, 2022',
        description: 'A small step towards women’s empowerment but a giant step towards human development!'
      },
      {
        title: 'Visit of Honorable Prime Minister Shri Narendra Modi Ji at Symbiosis',
        date: '7 March, 2022',
        description: 'Hon’ble Prime Minister Shri. Narendra Modi Ji visited Symbiosis to commemorate golden jubilee celebrations!'
      },
      {
        title: 'Symbiosis FICCI HE Excellence Award 2020',
        date: '25 February, 2021',
        description: 'Federation of Indian Chamber of Commerce & Industry (FICCI) is conferring the ‘Lifetime Achievement Award’, to our Founder & President Dr. S B Mujumdar Sir'
      },
      {
        title: 'Asian Association of Open Universities AAOU 2022',
        date: '25 August, 2020',
        description: 'SCDL is an active member of Asian Association...'
      }
    ];
  }

  ngOnInit(): void {
  }

  getImagePath(index: number): string {
    const images = [
      'assets/events/event1.jpg',
      'assets/events/event2.jpg',
      'assets/events/event3.jpg',
      'assets/events/event4.jpg'
    ];
    return images[index];
  }
  getRegistrationLink(index: number): string {
    const links = [
      'https://www.scdl.net/news-events.aspx',
      'https://www.scdl.net/news-events.aspx',
      'https://www.scdl.net/news-events.aspx',
      'https://www.scdl.net/news-events.aspx'
    ];
    return links[index];
  }
}
