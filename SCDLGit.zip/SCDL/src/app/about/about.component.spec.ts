import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutComponent } from './about.component';

describe('AboutComponent', () => {
  let component: AboutComponent;
  let fixture: ComponentFixture<AboutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AboutComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AboutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should render the header', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.about-header h1').textContent).toContain('About Us');
  });

  it('should render the about text', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.about-text h2').textContent).toContain('We are the best institute since 1995');
  });

  it('should render the admission section', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.admission-section h3').textContent).toContain('Apply For Admission');
  });

  it('should render the teachers section', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.teachers-section h3').textContent).toContain('Our Experienced And Expert Teachers');
  });

  it('should render the stats section', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.stats-section .stat h4').textContent).toContain('1200+');
  });

  it('should render the video section', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.video-section h3').textContent).toContain('Watch The Video Of Our Campus Life');
  });

  it('should render the testimonial section', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.testimonial-section h3').textContent).toContain('Our Students Valuable Comments');
  });
});
