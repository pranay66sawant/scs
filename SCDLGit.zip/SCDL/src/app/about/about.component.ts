import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent {
  currentSlide: number = 0;
  slides: string[] = [
    'assets/about/director1.png',
    'assets/about/director2.png',
    'assets/about/Director3.png',
    'assets/about/director4.png',

    // Add more image paths as needed
  ];

  changeSlide(direction: number) {
    this.currentSlide = (this.currentSlide + direction + this.slides.length) % this.slides.length;
  }
}