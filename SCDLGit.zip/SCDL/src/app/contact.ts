export class Contact {
    id!: number;
    firstName!: string;
    lastName!: string;
    emailId!: string;
    phone!:string;
    message!:string;

}
